# ShieldX React Project

Run using:
npx create-react-app shieldx
Replace src files with these files.
