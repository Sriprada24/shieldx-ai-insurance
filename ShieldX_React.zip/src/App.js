import React, { useState } from "react";
import "./App.css";

function App() {
  const [risk, setRisk] = useState(0);
  const [premium, setPremium] = useState(0);
  const [claim, setClaim] = useState("");

  const calculateRisk = () => {
    let weather = "rain";
    let pollution = 120;

    let r = 0;
    if (weather === "rain") r += 40;
    if (pollution > 100) r += 30;

    setRisk(r);
    setPremium(50 + r * 0.5);
  };

  const simulateClaim = () => {
    setClaim("✅ Claim Approved! ₹500 credited");
  };

  return (
    <div className="container">
      <h1>ShieldX 🚀</h1>
      <h2>AI Insurance for Delivery Workers</h2>

      <button onClick={calculateRisk}>Calculate Risk</button>

      <p>Risk Score: {risk}</p>
      <p>Weekly Premium: ₹{premium}</p>

      <button onClick={simulateClaim}>Simulate Rain Claim</button>

      <h3>{claim}</h3>
    </div>
  );
}

export default App;
